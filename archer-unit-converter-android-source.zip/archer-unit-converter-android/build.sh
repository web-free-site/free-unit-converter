#!/bin/sh
# Builds archer-unit-converter.apk without Gradle, using only the
# Android SDK build-tools (aapt2 / d8 / zipalign / apksigner) + a JDK.
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
# A JRE-only JAVA_HOME is no good here — we need javac.
if [ ! -x "$JAVA_HOME/bin/javac" ]; then
  JAVA_HOME=/home/claude/jdk
fi
SDK="${ANDROID_SDK_ROOT:-/home/claude/android-sdk}"
BT="$SDK/build-tools/36.1.0"
PLATFORM="$SDK/platforms/android-34/android.jar"
OUT="${1:-$APP_DIR/build/archer-unit-converter.apk}"

export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"

cd "$APP_DIR"
rm -rf build/classes build/dex build/res.zip build/base.apk build/aligned.apk
mkdir -p build/classes build/dex

echo "1/6  compiling resources"
"$BT/aapt2" compile --dir res -o build/res.zip

echo "2/6  linking resources + assets"
"$BT/aapt2" link \
  -o build/base.apk \
  -I "$PLATFORM" \
  --manifest AndroidManifest.xml \
  -A assets \
  --min-sdk-version 21 \
  --target-sdk-version 34 \
  --version-code 1 \
  --version-name 1.0 \
  build/res.zip

echo "3/6  compiling java"
javac --release 8 -nowarn -classpath "$PLATFORM" -d build/classes \
  $(find src -name '*.java')

echo "4/6  dexing"
"$BT/d8" --lib "$PLATFORM" --min-api 21 --output build/dex \
  $(find build/classes -name '*.class')

echo "5/6  packaging + aligning"
python3 - <<'PY'
import shutil, zipfile
shutil.copy('build/base.apk', 'build/unsigned.apk')
with zipfile.ZipFile('build/unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as z:
    z.write('build/dex/classes.dex', 'classes.dex')
PY
"$BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk

echo "6/6  signing"
if [ ! -f build/archer.keystore ]; then
  keytool -genkeypair -keystore build/archer.keystore -alias archer \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass archer123 -keypass archer123 \
    -dname "CN=Archer Unit Converter, OU=Wireline, O=Archer, C=MY" >/dev/null 2>&1
fi
"$BT/apksigner" sign \
  --ks build/archer.keystore \
  --ks-pass pass:archer123 \
  --key-pass pass:archer123 \
  --v1-signing-enabled true \
  --v2-signing-enabled true \
  --out "$OUT" \
  build/aligned.apk

"$BT/apksigner" verify --print-certs "$OUT" | head -3
echo "built: $OUT"
